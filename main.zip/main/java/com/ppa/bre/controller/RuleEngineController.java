package com.ppa.bre.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.catalina.core.FrameworkListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ppa.bre.dto.MetadataDto;
import com.ppa.bre.dto.RuleDescriptionDto;
import com.ppa.bre.dto.RuleMappingDto;
import com.ppa.bre.dto.RuleMasterDto;
import com.ppa.bre.dto.RuleNameDto;
import com.ppa.bre.service.RuleMappingService;
import com.ppa.bre.service.RuleMasterService;
import com.ppa.bre.service.RuleMetadataService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class RuleEngineController {

	private static final Logger LOGGER = LoggerFactory.getLogger(RuleEngineController.class);

	@Autowired
	private RuleMappingService ruleMappingService;
	@Autowired
	private RuleMasterService ruleMasterService;
	@Autowired
	private RuleMetadataService ruleMetadataService;
	

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/rule-mapping")
	public ResponseEntity<List<RuleMappingDto>> getRuleMappings() {
		List<RuleMappingDto> list = ruleMappingService.getRuleMappings();
		LOGGER.info("Inside getRuleMapping {}", list.get(0).toString());
		return new ResponseEntity<List<RuleMappingDto>>(list, HttpStatus.OK);
	}

	@PostMapping("/rule-mapping")
	public ResponseEntity<String> postRuleMapping(@RequestBody RuleMappingDto ruleMappingDto) {
		List<RuleMappingDto>list=ruleMappingService.getRuleMappings();
		boolean isPresent=false;
		String msg;
		for(RuleMappingDto dto:list) {
			if(dto.getRuleName().equals(ruleMappingDto.getRuleName()) && dto.getSchemaName().equals(ruleMappingDto.getSchemaName()) && dto.getTableName().equals(ruleMappingDto.getTableName()) && dto.getAttribute().equals(ruleMappingDto.getAttribute())) {
				isPresent=true;
				break;
			}
		}
		if(isPresent==true) {
			msg="Data Already Present in Database";
		}
		else {
			RuleMappingDto dto = ruleMappingService.postRuleMapping(ruleMappingDto);
			msg="Data Saved Successfully";
		}
		
		LOGGER.info("Inside postRuleMapping {}", msg);
		return new ResponseEntity<String>(msg, HttpStatus.OK);
	}
	//@CrossOrigin(origins = "http://localhost:4200")
	//List<String> ruleIds = new ArrayList<>(
      //      List.of("R1"));
	
	/*
	 * @RequestMapping(value = "/rule-mapping/{ruleIds}",method =
	 * RequestMethod.DELETE) //@ResponseBody public ResponseEntity<?>
	 * deleteByIds(@PathVariable List<Integer> ruleIds){ ruleIds.forEach(d->{
	 * if(ruleMappingService.existByid(d)){ ruleMappingService.deleteById(d); } });
	 * return ResponseEntity.ok().body("Customers has been removed"); }
	 */

	@RequestMapping(value = "/rule-mapping/{ruleIds}",method = RequestMethod.DELETE)
	//@ResponseBody
	public ResponseEntity<?> deleteByIds(@PathVariable List<Integer> ruleIds){
		ruleMappingService.deleteRuleMapping(ruleIds);
		 return ResponseEntity.ok().body("Customers has been removed");
	}
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/rule")
	public ResponseEntity<List<RuleMasterDto>> getRules() {
		List<RuleMasterDto> list = ruleMasterService.getRules();
		LOGGER.info("Inside getRules {}", list.get(0).toString());
		return new ResponseEntity<List<RuleMasterDto>>(list, HttpStatus.OK);
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/rule/{ruleName}")
	public ResponseEntity<RuleMasterDto> getRuleByName(@PathVariable String ruleName) {
		RuleMasterDto ruleMasterDto = ruleMasterService.getRuleByName(ruleName);
		LOGGER.info("Inside getRuleByName {}", ruleMasterDto.toString());
		return new ResponseEntity<RuleMasterDto>(ruleMasterDto, HttpStatus.OK);
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping("/metadata")
	public ResponseEntity<MetadataDto> getMetadata(@RequestParam(required = false) String schema,
			@RequestParam(required = false) String tableName) {

		List<String> list;
		MetadataDto dto = new MetadataDto();
		if (schema == null && tableName == null) {
			list = ruleMetadataService.fetchSchemaList();
			LOGGER.info("Inside getMetada(fetch schema list) {}", list.size());
			dto.setSchemas(list);
			return new ResponseEntity<MetadataDto>(dto, HttpStatus.OK);

		} else if (schema != null && tableName != null) {
			list = ruleMetadataService.fetchAttributes(schema, tableName);
			LOGGER.info("Inside getMetada(fetch attribute list) {}", list.size());
			dto.setAttributes(list);
			return new ResponseEntity<MetadataDto>(dto, HttpStatus.OK);
		} else {
			list = ruleMetadataService.fetchTableList(schema);
			LOGGER.info("Inside getMetada(fetch table list) {}", list.size());
			dto.setTables(list);
			return new ResponseEntity<MetadataDto>(dto, HttpStatus.OK);
		}
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping("/rule-description")
	public ResponseEntity<RuleDescriptionDto> getRuleDescription(@RequestParam String ruleName) {
		RuleDescriptionDto dto=new RuleDescriptionDto();
		String descr = ruleMasterService.getRuleDescription(ruleName);
		LOGGER.info("Inside getRuleDescription {}", descr);
		dto.setRuleDescription(descr);
		return new ResponseEntity<>(dto, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/rule-name")
	public ResponseEntity<RuleNameDto> getRuleNames() {
		RuleNameDto dto = new RuleNameDto();
		List<String> namesList = ruleMasterService.getRuleNames();
		LOGGER.info("Inside getRuleNames {}", namesList.size());
		dto.setRuleName(namesList);
		return new ResponseEntity<>(dto, HttpStatus.OK);
	}
	
}
