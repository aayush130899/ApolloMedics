package com.ppa.bre.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "RULE_MAPPING")
public class RuleMapping {
	@Column(name = "ID")
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Column(name = "SCHEMA_NAME")
	private String schemaName;
	@Column(name = "TABLE_NAME")
	private String tableName;
	@Column(name = "ATTRIBUTE")
	private String attribute;
	@Column(name = "RULE_ID")
	private String ruleId;
	@Column(name = "IS_ACTIVE")
	private boolean isActive;
	@Column(name = "RULE_NAME")
	private String ruleName;

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public RuleMapping() {
		super();

	}

	public RuleMapping(int id, String schemaName, String tableName, String attribute, String ruleId, boolean isActive,String ruleName) {
		super();
		this.id = id;
		this.schemaName = schemaName;
		this.tableName = tableName;
		this.attribute = attribute;
		this.ruleId = ruleId;
		this.isActive = isActive;
		this.ruleName=ruleName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSchemaName() {
		return schemaName;
	}

	public void setSchemaName(String schemaName) {
		this.schemaName = schemaName;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getAttribute() {
		return attribute;
	}

	public void setAttribute(String attribute) {
		this.attribute = attribute;
	}

	public String getRuleId() {
		return ruleId;
	}

	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}

	public boolean getActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

}
