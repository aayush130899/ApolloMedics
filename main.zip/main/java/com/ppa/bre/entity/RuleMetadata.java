package com.ppa.bre.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "RULE_METADATA")
public class RuleMetadata {

	@Column
	@Id
	private int id;
	@Column(name = "SCHEMA_NAME")
	private String schemaName;
	@Column(name = "TABLE_NAME")
	private String tableName;
	@Column(name = "COLUMN_NAME")
	private String columnName;

	public int getId() {
		return id;
	}

	public RuleMetadata() {
		super();
	}

	public RuleMetadata(int id, String schemaName, String tableName, String columnName) {
		super();
		this.id = id;
		this.schemaName = schemaName;
		this.tableName = tableName;
		this.columnName = columnName;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSchemaName() {
		return schemaName;
	}

	public void setSchemaName(String schemaName) {
		this.schemaName = schemaName;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
}
