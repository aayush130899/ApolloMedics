package com.ppa.bre.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ppa.bre.entity.RuleMetadata;

public interface RuleMetadataDao extends JpaRepository<RuleMetadata, Integer> {
	@Query(value = "SELECT DISTINCT SCHEMA_NAME FROM RULE_METADATA", nativeQuery = true)
	List<String> fetchSchemaList();

	@Query(value = "SELECT DISTINCT TABLE_NAME FROM RULE_METADATA rm WHERE rm.SCHEMA_NAME=?1", nativeQuery = true)
	List<String> findTableBySchemaName(String schema);

	@Query(value = "SELECT DISTINCT COLUMN_NAME FROM RULE_METADATA rm where rm.SCHEMA_NAME=?1 and rm.TABLE_NAME=?2", nativeQuery = true)
	List<String> findColumnName(String schema, String table);
}
