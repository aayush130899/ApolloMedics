package com.ppa.bre.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ppa.bre.entity.RuleMaster;

public interface RuleMasterDao extends JpaRepository<RuleMaster, Integer> {

	public RuleMaster findByRuleName(String ruleName);

	@Query(value = "SELECT RULE_DESCRIPTION FROM RULE_MASTER rm WHERE rm.RULE_NAME=?1", nativeQuery = true)
	public String getRuleDescription(String ruleName);

	@Query(value = "SELECT rm.RULE_NAME FROM RULE_MASTER rm", nativeQuery = true)
	public List<String> getRuleNames();
}
