package com.ppa.bre.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import com.ppa.bre.entity.RuleMapping;

public interface RuleMappingDao extends CrudRepository<RuleMapping, Integer> {
	
	//String query = String.Format("select * from GEMSSProduct where product_Id in ({0})", String.Join(",", productIds));

	
	/*
	 * @Modifying
	 * 
	 * @Transactional
	 * 
	 * @Query(value
	 * ="DELETE FROM RULE_MAPPING rm WHERE rm.RULE_ID IN(:ruleIds)",nativeQuery =
	 * true) void deleteAllByRuleId(List<Integer>ruleIds);
	 */
	 
	/*
	 * @Query(value =
	 * "select case when count(*)> 0 then 'true' else 'false' end from RULE_MAPPING where ID=:d"
	 * ,nativeQuery = true) boolean existByRuleId(int d);
	 * 
	 * @Query(value = "DELETE FROM RULE_MAPPING WHERE ID=:d",nativeQuery = true)
	 * void deleteByRuleId(int d);
	 */
	
}
