package com.ppa.bre.assembler;

import com.ppa.bre.dto.RuleMetadataDto;
import com.ppa.bre.entity.RuleMetadata;

public class RuleMetadataAssembler {

	public static RuleMetadataDto toDto(RuleMetadata ruleMetadata) {
		RuleMetadataDto ruleMetadataDto = new RuleMetadataDto();
		ruleMetadataDto.setId(ruleMetadata.getId());
		ruleMetadataDto.setSchemaName(ruleMetadata.getSchemaName());
		ruleMetadataDto.setColumnName(ruleMetadata.getColumnName());
		ruleMetadataDto.setTableName(ruleMetadata.getTableName());

		return ruleMetadataDto;
	}

}
