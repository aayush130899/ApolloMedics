package com.ppa.bre.assembler;

import com.ppa.bre.dto.RuleMappingDto;
import com.ppa.bre.entity.RuleMapping;

public class RuleMappingAssembler {

	public static RuleMapping toEntity(RuleMappingDto ruleMappingDto) {
		RuleMapping entity = new RuleMapping();
		entity.setId(ruleMappingDto.getId());
		entity.setAttribute(ruleMappingDto.getAttribute());
		entity.setRuleId(ruleMappingDto.getRuleId());
		entity.setSchemaName(ruleMappingDto.getSchemaName());
		entity.setActive(ruleMappingDto.isActive());
		entity.setTableName(ruleMappingDto.getTableName());
		entity.setRuleName(ruleMappingDto.getRuleName());
		return entity;
	}

	public static RuleMappingDto toDto(RuleMapping ruleMapping) {
		RuleMappingDto dto = new RuleMappingDto();
		dto.setId(ruleMapping.getId());
		dto.setAttribute(ruleMapping.getAttribute());
		dto.setRuleId(ruleMapping.getRuleId());
		dto.setSchemaName(ruleMapping.getSchemaName());
		dto.setActive(ruleMapping.getActive());
		dto.setTableName(ruleMapping.getTableName());
		dto.setRuleName(ruleMapping.getRuleName());
		return dto;
	}
}
