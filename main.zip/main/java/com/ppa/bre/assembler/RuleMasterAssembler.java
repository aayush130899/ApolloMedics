package com.ppa.bre.assembler;

import com.ppa.bre.dto.RuleMasterDto;
import com.ppa.bre.entity.RuleMaster;

public class RuleMasterAssembler {

	public static RuleMasterDto toDto(RuleMaster ruleMaster) {

		RuleMasterDto dto = new RuleMasterDto();
		dto.setRuleId(ruleMaster.getRuleId());
		dto.setRuleCondition(ruleMaster.getRuleCondition());
		dto.setRuleName(ruleMaster.getRuleName());
		dto.setRuleDescription(ruleMaster.getRuleDescription());
		dto.setId(ruleMaster.getId());
		dto.setLookupCondition(ruleMaster.getLookupCondition());
		dto.setLookupColumnName(ruleMaster.getLookupColumnName());
		dto.setLookup(ruleMaster.isLookup());
		dto.setRule(ruleMaster.isRule());
		dto.setLookupTable(ruleMaster.getLookupTable());

		return dto;
	}

}
