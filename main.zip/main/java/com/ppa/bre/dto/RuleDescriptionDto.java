package com.ppa.bre.dto;

public class RuleDescriptionDto {
	
	private String ruleDescription;

	public String getRuleDescription() {
		return ruleDescription;
	}

	public void setRuleDescription(String ruleDescription) {
		this.ruleDescription = ruleDescription;
	}

}
