package com.ppa.bre.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RuleMappingDto {
	@JsonProperty("id")
	private int id;
	@JsonProperty("schemaName")
	private String schemaName;
	@JsonProperty("ruleId")
	private String ruleId;
	@JsonProperty("attribute")
	private String attribute;
	@JsonProperty("isActive")
	private boolean active;
	@JsonProperty("tableName")
	private String tableName;
	@JsonProperty("ruleName")
	private String ruleName;

	public String getRuleId() {
		return ruleId;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}

	@Override
	public String toString() {
		return "RuleMappingDto [id=" + id + ", schemaName=" + schemaName + ", ruleId=" + ruleId + ", attribute="
				+ attribute + ", active=" + active + ", tableName=" + tableName + ", ruleName=" + ruleName + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSchemaName() {
		return schemaName;
	}

	public void setSchemaName(String schemaName) {
		this.schemaName = schemaName;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getAttribute() {
		return attribute;
	}

	public void setAttribute(String attribute) {
		this.attribute = attribute;
	}

	public RuleMappingDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RuleMappingDto(int id, String schemaName, String ruleId, boolean isActive, String tableName,
			String attribute,String ruleName) {
		super();
		this.id = id;
		this.schemaName = schemaName;
		this.tableName = tableName;
		this.attribute = attribute;
		this.ruleId = ruleId;
		this.active = isActive;
		this.ruleName=ruleName;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

}
