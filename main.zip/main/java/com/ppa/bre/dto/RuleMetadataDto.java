package com.ppa.bre.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RuleMetadataDto {

	@JsonProperty("id")
	private int id;
	@JsonProperty("schemaName")
	private String schemaName;
	@JsonProperty("tableName")
	private String tableName;
	@JsonProperty("columnName")
	private String columnName;

	public RuleMetadataDto() {
		super();
	}

	public RuleMetadataDto(int id, String schemaName, String tableName, String columnName) {
		super();
		this.id = id;
		this.schemaName = schemaName;
		this.tableName = tableName;
		this.columnName = columnName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSchemaName() {
		return schemaName;
	}

	public void setSchemaName(String schemaName) {
		this.schemaName = schemaName;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

}
