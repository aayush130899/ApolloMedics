package com.ppa.bre.dto;

import java.util.List;

public class RuleNameDto {
	private List<String> ruleName;
	private String rname;

	public List<String> getRuleName() {
		return ruleName;
	}

	public void setRuleName(List<String> ruleName) {
		this.ruleName = ruleName;
	} 

}
