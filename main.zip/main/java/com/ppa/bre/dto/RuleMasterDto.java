package com.ppa.bre.dto;

public class RuleMasterDto {
	private int id;
	private String ruleId;
	private String ruleName;
	private String ruleDescription;
	private String ruleCondition;
	private boolean isRule;
	private boolean isLookup;
	private String lookupCondition;
	private String lookupColumnName;
	private String lookupTable;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRuleId() {
		return ruleId;
	}

	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}

	public boolean isRule() {
		return isRule;
	}

	public void setRule(boolean isRule) {
		this.isRule = isRule;
	}

	public boolean isLookup() {
		return isLookup;
	}

	public void setLookup(boolean isLookup) {
		this.isLookup = isLookup;
	}

	public String getLookupCondition() {
		return lookupCondition;
	}

	public void setLookupCondition(String lookupCondition) {
		this.lookupCondition = lookupCondition;
	}

	public String getLookupColumnName() {
		return lookupColumnName;
	}

	public void setLookupColumnName(String lookupColumnName) {
		this.lookupColumnName = lookupColumnName;
	}

	public String getLookupTable() {
		return lookupTable;
	}

	public void setLookupTable(String lookupTable) {
		this.lookupTable = lookupTable;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public String getRuleDescription() {
		return ruleDescription;
	}

	public void setRuleDescription(String ruleDescription) {
		this.ruleDescription = ruleDescription;
	}

	public String getRuleCondition() {
		return ruleCondition;
	}

	public void setRuleCondition(String ruleCondition) {
		this.ruleCondition = ruleCondition;
	}

	public RuleMasterDto() {
		super();

	}

	public RuleMasterDto(int id, String ruleId, String ruleName, String ruleDescription, String ruleCondition,
			boolean isRule, boolean isLookup, String lookupCondition, String lookupColumnName, String lookupTable) {
		super();
		this.id = id;
		this.ruleId = ruleId;
		this.ruleName = ruleName;
		this.ruleDescription = ruleDescription;
		this.ruleCondition = ruleCondition;
		this.isRule = isRule;
		this.isLookup = isLookup;
		this.lookupCondition = lookupCondition;
		this.lookupColumnName = lookupColumnName;
		this.lookupTable = lookupTable;
	}

}