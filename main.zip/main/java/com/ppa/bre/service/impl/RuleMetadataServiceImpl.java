package com.ppa.bre.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ppa.bre.dao.RuleMetadataDao;
import com.ppa.bre.service.RuleMetadataService;

@Service
public class RuleMetadataServiceImpl implements RuleMetadataService {

	private static final Logger LOGGER = LoggerFactory.getLogger(RuleMetadataServiceImpl.class);

	@Autowired
	private RuleMetadataDao ruleMetadataDao;

	@Override
	public List<String> fetchSchemaList() {

		List<String> list = ruleMetadataDao.fetchSchemaList();
		LOGGER.info("Inside RuleMetadataServiceImpl.fetchSchemaList {}", list.size());
		return list;
	}

	@Override
	public List<String> fetchAttributes(String schema, String table) {

		List<String> list = ruleMetadataDao.findColumnName(schema, table);
		LOGGER.info("Inside RuleMetadataServiceImpl.fetchAttributes {}", list.size());
		return list;
	}

	@Override
	public List<String> fetchTableList(String schema) {

		List<String> list = ruleMetadataDao.findTableBySchemaName(schema);
		LOGGER.info("Inside RuleMetadataServiceImpl.fetchTableList {}", list.size());
		return list;
	}

}
