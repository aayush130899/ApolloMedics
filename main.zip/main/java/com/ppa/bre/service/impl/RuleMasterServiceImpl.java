package com.ppa.bre.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ppa.bre.assembler.RuleMasterAssembler;
import com.ppa.bre.dao.RuleMasterDao;
import com.ppa.bre.dto.RuleMasterDto;
import com.ppa.bre.entity.RuleMaster;
import com.ppa.bre.service.RuleMasterService;

@Service
public class RuleMasterServiceImpl implements RuleMasterService {

	private static final Logger LOGGER = LoggerFactory.getLogger(RuleMasterServiceImpl.class);

	@Autowired
	private RuleMasterDao ruleMasterDao;

	@Override
	public RuleMasterDto getRuleByName(String ruleName) {
		RuleMaster ruleMaster = ruleMasterDao.findByRuleName(ruleName);
		RuleMasterDto ruleMasterDto = RuleMasterAssembler.toDto(ruleMaster);
		LOGGER.info("Inside RuleMasterServiceImpl.getRuleByName {}", ruleMasterDto.toString());
		return ruleMasterDto;
	}

	@Override
	public List<RuleMasterDto> getRules() {
		List<RuleMasterDto> rules = new ArrayList<>();
		List<RuleMaster> rulesm = ruleMasterDao.findAll();
		for (RuleMaster r : rulesm) {
			rules.add(RuleMasterAssembler.toDto(r));
		}
		LOGGER.info("Inside RuleMasterServiceImpl.getRules {}", rules.size());
		return rules;
	}

	@Override
	public String getRuleDescription(String ruleName) {
		String descr = ruleMasterDao.getRuleDescription(ruleName);
		LOGGER.info("Inside RuleMasterServiceImpl.getRuleDescription {}", descr);
		return descr;
	}

	@Override
	public List<String> getRuleNames() {

		List<String> ruleNamesList = ruleMasterDao.getRuleNames();
		LOGGER.info("Inside RuleMasterServiceImpl.getRuleNames {}", ruleNamesList.size());
		return ruleNamesList;
	}
}
