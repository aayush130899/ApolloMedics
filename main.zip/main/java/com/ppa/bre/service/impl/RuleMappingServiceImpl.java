package com.ppa.bre.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ppa.bre.assembler.RuleMappingAssembler;
import com.ppa.bre.dao.RuleMappingDao;
import com.ppa.bre.dto.RuleMappingDto;
import com.ppa.bre.entity.RuleMapping;
import com.ppa.bre.service.RuleMappingService;

@Service
public class RuleMappingServiceImpl implements RuleMappingService {

	private static final Logger LOGGER = LoggerFactory.getLogger(RuleMappingServiceImpl.class);

	@Autowired
	private RuleMappingDao ruleMappingDao;

	@Override
	@Transactional
	public List<RuleMappingDto> getRuleMappings() {
		List<RuleMappingDto> ruleMappingDto = new ArrayList<>();

		List<RuleMapping> ruleMappings = (List<RuleMapping>) ruleMappingDao.findAll();

		for (RuleMapping rulemp : ruleMappings) {
			ruleMappingDto.add(RuleMappingAssembler.toDto(rulemp));
		}
		LOGGER.info("Inside RuleMappingServiceImpl.getRuleMapping {}", ruleMappingDto.size());
		return ruleMappingDto;
	}

	@Override
	@Transactional
	public RuleMappingDto postRuleMapping(RuleMappingDto ruleMappingDto) {
		RuleMapping ruleMapping = RuleMappingAssembler.toEntity(ruleMappingDto);
		RuleMapping savedMapping = ruleMappingDao.save(ruleMapping);
		RuleMappingDto dto = RuleMappingAssembler.toDto(savedMapping);
		LOGGER.info("Inside RuleMappingServiceImpl.postRuleMapping {}", dto.toString());
		return dto;
	}

	
	 @Override
	 @Transactional 
	 public void deleteRuleMapping(List<Integer>ruleIds) { 
			 //ruleMappingDao.deleteAllByRuleId(ruleIds);  
			 ruleMappingDao.deleteAllById(ruleIds);
	  }

	@Override
	public boolean existByid(int d) {
		// TODO Auto-generated method stub
		return ruleMappingDao.existsById(d);
	}

	@Transactional
	@Override
	public void deleteById(int d) {
		// TODO Auto-generated method stub
		ruleMappingDao.deleteById(d);
	}

}
