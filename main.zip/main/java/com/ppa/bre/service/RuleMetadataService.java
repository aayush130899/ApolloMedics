package com.ppa.bre.service;

import java.util.List;

public interface RuleMetadataService {

	List<String> fetchSchemaList();

	List<String> fetchAttributes(String schema, String table);

	List<String> fetchTableList(String schema);

}
