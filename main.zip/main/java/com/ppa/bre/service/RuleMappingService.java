package com.ppa.bre.service;

import java.util.List;

import com.ppa.bre.dto.RuleMappingDto;

public interface RuleMappingService {
	public List<RuleMappingDto> getRuleMappings();

	public RuleMappingDto postRuleMapping(RuleMappingDto ruleMappingDto);

	public void deleteRuleMapping(List<Integer>ruleIds);

	public boolean existByid(int d);

	public void deleteById(int d);
}
