package com.ppa.bre.service;

import java.util.List;

import com.ppa.bre.dto.RuleMasterDto;

public interface RuleMasterService {

	public RuleMasterDto getRuleByName(String ruleName);

	public List<RuleMasterDto> getRules();

	public String getRuleDescription(String ruleId);

	public List<String> getRuleNames();

}
