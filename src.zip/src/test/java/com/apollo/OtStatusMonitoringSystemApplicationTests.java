package com.apollo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OtStatusMonitoringSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
