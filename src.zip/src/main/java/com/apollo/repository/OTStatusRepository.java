package com.apollo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.apollo.entity.OTStatus;

public interface OTStatusRepository extends JpaRepository<OTStatus,Long> {

	@Query(value="SELECT ot.UHID,ot.STATUS,ot.SURGEON_NAME,ot.OT_NUMBER FROM OT_STATUS ot WHERE ot.UHID=:UHID",nativeQuery = true)
	OTStatus findByUHID(long UHID);
	
}
