package com.apollo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.apollo.entity.OTStatus;
import com.apollo.repository.OTMetadataRepository;
import com.apollo.repository.OTStatusRepository;
import com.apollo.service.OTStatusService;
@Service
public class OTStatusServiceImpl implements OTStatusService {

	@Autowired
	private OTStatusRepository otStatusRepository;
	@Autowired
	private OTMetadataRepository otMetadataRepository;
	@Override
	public List<OTStatus> getAllOTStatus() {
		// TODO Auto-generated method stub
		return otStatusRepository.findAll();
	}
	@Override
	public OTStatus getOTStatusByUHID(long UHID) {
		// TODO Auto-generated method stub
		return otStatusRepository.findByUHID(UHID);
	}
	@Override
	public OTStatus createOTStatus(OTStatus otStatus) {
		// TODO Auto-generated method stub
		return otStatusRepository.save(otStatus);
	}
	@Override
	public OTStatus updateOTStatus(OTStatus otStatus) {
		// TODO Auto-generated method stub
		return otStatusRepository.save(otStatus);
	}
	@Override
	public void deleteOTStatus(long UHID) {
		// TODO Auto-generated method stub
		otStatusRepository.deleteById(UHID);
	}
	@Override
	public List<String> getStatusFromMetadata() {
		// TODO Auto-generated method stub
		return otMetadataRepository.getAllStatus();
	}

}
