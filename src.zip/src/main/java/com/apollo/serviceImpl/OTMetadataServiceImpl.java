package com.apollo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.apollo.entity.OTMetadata;
import com.apollo.repository.OTMetadataRepository;
import com.apollo.service.OTMetadataService;

@Service
public class OTMetadataServiceImpl implements OTMetadataService {

	@Autowired
	private OTMetadataRepository otMetadataRepository;
	@Override
	public List<OTMetadata> getOTMetadata() {
		// TODO Auto-generated method stub
		return otMetadataRepository.findAll();
	}

}
