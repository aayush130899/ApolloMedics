package com.apollo.dto;

import java.util.List;

public class OTStatusDto {

	private List<String> status;

	public List<String> getStatus() {
		return status;
	}

	public void setStatus(List<String> status) {
		this.status = status;
	}

	public OTStatusDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OTStatusDto(List<String> status) {
		super();
		this.status = status;
	}
}
