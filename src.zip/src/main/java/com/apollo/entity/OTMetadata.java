package com.apollo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "OT_METADATA")
public class OTMetadata {
	@Column(name = "STATUS")
	private String status;
	@Column(name = "ID")
	@Id
	private int Id;

	public OTMetadata(String status, int id) {
		super();
		this.status = status;
		Id = id;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public OTMetadata() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
