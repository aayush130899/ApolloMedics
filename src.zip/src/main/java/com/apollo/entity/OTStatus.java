package com.apollo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "OT_STATUS")
public class OTStatus {

	@Id
	@Column(name = "UHID")
	private long UHID;
	public OTStatus(long uHID, String status, String surgeonName, int otNumber) {
		super();
		UHID = uHID;
		this.status = status;
		this.surgeonName = surgeonName;
		this.otNumber = otNumber;
	}
	public OTStatus() {
		super();
		// TODO Auto-generated constructor stub
	}
	public long getUHID() {
		return UHID;
	}
	public void setUHID(long uHID) {
		UHID = uHID;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSurgeonName() {
		return surgeonName;
	}
	public void setSurgeonName(String surgeonName) {
		this.surgeonName = surgeonName;
	}
	public int getOtNumber() {
		return otNumber;
	}
	public void setOtNumber(int otNumber) {
		this.otNumber = otNumber;
	}
	@Column(name = "STATUS")
	private String status;
	@Column(name = "SURGEON_NAME")
	private String surgeonName;
	@Column(name = "OT_NUMBER")
	private int otNumber;
}
