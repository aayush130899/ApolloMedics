package com.apollo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OtStatusMonitoringSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OtStatusMonitoringSystemApplication.class, args);
	}

}
