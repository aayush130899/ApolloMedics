package com.apollo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.apollo.dto.OTStatusDto;
import com.apollo.entity.OTMetadata;
import com.apollo.entity.OTStatus;
import com.apollo.service.OTMetadataService;
import com.apollo.service.OTStatusService;

@RestController
@CrossOrigin("http://localhost:4200")
public class OTStatusController {
	
	@Autowired
	private OTStatusService otStatusService;
	@Autowired
	private OTMetadataService otMetadataService;

	@GetMapping("/all-status")
	public List<OTStatus> getAllOTStatus(){
		return otStatusService.getAllOTStatus();
	}
	
	@GetMapping("/all-status/{UHID}")
	public ResponseEntity<OTStatus> getOTStatusByUHID(@PathVariable long UHID) {
		OTStatus otStatus=otStatusService.getOTStatusByUHID(UHID);
		if(otStatus==null) {
			return new ResponseEntity<OTStatus>(otStatus, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<OTStatus>(otStatus, HttpStatus.OK);
	}
	@CrossOrigin("http://localhost:4200")
	@PostMapping("/all-status")
	public OTStatus createOTStatus(@RequestBody OTStatus otStatus) {
		return otStatusService.createOTStatus(otStatus);
	}
	
	@PutMapping("/all-status/{UHID}")
	public OTStatus updateOTStatus(@RequestBody OTStatus otStatus,@PathVariable long UHID) {
		return otStatusService.updateOTStatus(otStatus);
	}
	
	@DeleteMapping("/all-status/{UHID}")
	public void deleteOTStatus(@PathVariable long UHID) {
		otStatusService.deleteOTStatus(UHID);
	}
	
	
	@GetMapping("/metadata")
	public List<OTMetadata> getOTMetadata(){
		return otMetadataService.getOTMetadata();
	}
	@GetMapping("/metadata/status")
	public OTStatusDto getStatusFromMetadata(){
		OTStatusDto dto=new OTStatusDto();
		dto.setStatus(otStatusService.getStatusFromMetadata());
		return dto;
	}
}
