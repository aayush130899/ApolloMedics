package com.apollo.service;

import java.util.List;

import com.apollo.dto.OTStatusDto;
import com.apollo.entity.OTMetadata;
import com.apollo.entity.OTStatus;

public interface OTStatusService {

	public List<OTStatus> getAllOTStatus() ;

	public OTStatus getOTStatusByUHID(long UHID);

	public OTStatus createOTStatus(OTStatus otStatus);

	public OTStatus updateOTStatus(OTStatus otStatus);

	public void deleteOTStatus(long UHID);

	public List<String> getStatusFromMetadata();
}
