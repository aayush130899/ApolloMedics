package com.apollo.service;

import java.util.List;

import com.apollo.entity.OTMetadata;

public interface OTMetadataService {

	List<OTMetadata> getOTMetadata();

}
