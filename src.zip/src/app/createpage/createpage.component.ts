import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ToasterService } from '../toaster.service';

@Component({
  selector: 'app-createpage',
  templateUrl: './createpage.component.html',
  styleUrls: ['./createpage.component.scss']
})
export class CreatepageComponent implements OnInit {
  metadataList:any=[]
  constructor(private http:HttpClient,private toasterService:ToasterService) { }
  enUHID:any
  selectedStatus:any
  enSurgeonName:any
  enOTNumber:any
  saveMsg:boolean=false
  ngOnInit(): void {
    this.getOTMetadata()
  }
  Success(){
    this.toasterService.Success("Data saved successfully");
  }
  getOTMetadata(){
    this.http.get<any>('http://localhost:9091/metadata').subscribe(response=>{
    console.log(response)  
    this.metadataList=response;
    })
  }

  saveOTRecord(){
    const body={
      status: this.selectedStatus.status,
      surgeonName: this.enSurgeonName,
      otNumber: this.enOTNumber,
      uhid: this.enUHID
  }
    this.http.post<any>('http://localhost:9091/all-status',body).subscribe(resp=>{this.saveMsg=true})
  }

}
