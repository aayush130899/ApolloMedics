import { Injectable } from '@angular/core';
declare var toaster:any
@Injectable({
  providedIn: 'root'
})
export class ToasterService {

  constructor() { }

  Success(title:string,message?:string){
    toaster.success(title,message);
  }
  Warning(title:string,message?:any){
    toaster.warning(title,message);
  }
  Error(title:string,message?:any){
    toaster.error(title,message);
  }
  Info(title:string,message?:any){
    toaster.info(title,message);
  }
}
