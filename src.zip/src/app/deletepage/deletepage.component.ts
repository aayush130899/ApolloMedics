import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { FormControl, FormGroup} from '@angular/forms';
import { ToasterService } from '../toaster.service';
@Component({
  selector: 'app-deletepage',
  templateUrl: './deletepage.component.html',
  styleUrls: ['./deletepage.component.scss']
})
export class DeletepageComponent implements OnInit {

  statusList:any=[]
  metadataList:any=[]
 deleteMsg:boolean=false;
 UHID:any;
  deletedata=new FormGroup({
    uhid: new FormControl({value:'',disabled:true}),
    status: new FormControl({value:'',disabled:true}),
    surgeonName: new FormControl({value:'',disabled:true}),
    otNumber:new FormControl({value:'',disabled:true})
  })
  constructor(private http:HttpClient,private router:ActivatedRoute,private toasterService:ToasterService) {}

  ngOnInit(): void {
    this.getOTMetadata();
    console.log(this.router.snapshot.params['id']);
    this.getOTDataById(this.router.snapshot.params['id']).subscribe(response=>{
      console.log(response)
      this.UHID=response.uhid;
      this.deletedata=new FormGroup({
        uhid: new FormControl(response.uhid),
        status: new FormControl(response.status),
        surgeonName: new FormControl(response.surgeonName),
        otNumber:new FormControl(response.otNumber)
      })
    })
}
Success(){
  this.toasterService.Success("Data deleted successfully");
}
getAllStatus(){
  this.http.get<any>('http://localhost:9091/metadata/status').subscribe(response=>{
  console.log(response)  
  this.statusList=response;
  })
}
getOTMetadata(){
  this.http.get<any>('http://localhost:9091/metadata').subscribe(response=>{
  console.log(response)  
  this.metadataList=response;
  })
}
getOTDataById(id:any){
  return this.http.get<any>(`http://localhost:9091/all-status/${id}`);
}
deleteData(){
 this.http.delete<any>('http://localhost:9091/all-status/'+this.UHID).subscribe(resp=>{
   console.log(resp,'deleted successfully');
   this.deleteMsg=true;
 })
}
}



