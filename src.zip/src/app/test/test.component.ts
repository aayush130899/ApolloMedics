import { Component, OnInit } from '@angular/core';
import { EditpageComponent } from '../editpage/editpage.component';
import { MdbModalRef, MdbModalService } from 'mdb-angular-ui-kit/modal';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.scss']
})
export class TestComponent implements OnInit {

  modalRef: MdbModalRef<EditpageComponent>;

  constructor(private modalService: MdbModalService) {}

  openModal() {
    this.modalRef = this.modalService.open(EditpageComponent)
  }

  ngOnInit(): void {
  }

}

