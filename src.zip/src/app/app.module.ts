import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import {HttpClientModule} from '@angular/common/http'
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { EditpageComponent } from './editpage/editpage.component';
import { DeletepageComponent } from './deletepage/deletepage.component';
import { MdbModalModule } from 'mdb-angular-ui-kit/modal';
import { TestComponent } from './test/test.component';
import { RedirecttestComponent } from './redirecttest/redirecttest.component';
import { CreatepageComponent } from './createpage/createpage.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { AllStatusesComponent } from './all-statuses/all-statuses.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { ToasterService } from './toaster.service';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    EditpageComponent,
    DeletepageComponent,
    TestComponent,
    RedirecttestComponent,
    CreatepageComponent,
    HeaderComponent,
    FooterComponent,
    AllStatusesComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    MdbModalModule,
    ReactiveFormsModule,
    NgxPaginationModule
  ],
  providers: [ToasterService],
  bootstrap: [AppComponent]
})
export class AppModule { }
