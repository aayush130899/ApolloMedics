import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-redirecttest',
  templateUrl: './redirecttest.component.html',
  styleUrls: ['./redirecttest.component.scss']
})
export class RedirecttestComponent implements OnInit {

  constructor(private router:Router) { }

  redirect(){
    this.router.navigateByUrl('/edit-data');
  }
  ngOnInit(): void {
  }

}
