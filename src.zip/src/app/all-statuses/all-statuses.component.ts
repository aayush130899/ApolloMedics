import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-all-statuses',
  templateUrl: './all-statuses.component.html',
  styleUrls: ['./all-statuses.component.scss']
})
export class AllStatusesComponent implements OnInit {

  statusList:any=[];
  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    this.getAllStatus();
  }
  getAllStatus(){
    this.http.get<any>('http://localhost:9091/all-status').subscribe(response=>{
      this.statusList=response;
  })
  }
}
