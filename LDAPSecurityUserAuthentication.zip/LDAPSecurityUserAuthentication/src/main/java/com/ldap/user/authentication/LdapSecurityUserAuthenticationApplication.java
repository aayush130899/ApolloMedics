package com.ldap.user.authentication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LdapSecurityUserAuthenticationApplication {

	public static void main(String[] args) {
		SpringApplication.run(LdapSecurityUserAuthenticationApplication.class, args);
	}

}
