package com.ldap.user.authentication.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LDAPUserAuthenticationController {

		@RequestMapping(value="/login")
		public String login() {
			return "sign in";
	}
		@RequestMapping(value="/home")
		public String home() {
			return "index";
	}
		@RequestMapping(value="/")
		public String home1() {
			return "index";
	}
}
