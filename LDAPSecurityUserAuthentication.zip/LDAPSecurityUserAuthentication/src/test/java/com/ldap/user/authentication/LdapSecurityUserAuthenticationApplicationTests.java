package com.ldap.user.authentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LdapSecurityUserAuthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
