import { Component, OnInit } from '@angular/core';
import { MdbModalRef } from 'mdb-angular-ui-kit/modal';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { FormControl, FormGroup} from '@angular/forms';
@Component({
  selector: 'app-editpage',
  templateUrl: './editpage.component.html',
  styleUrls: ['./editpage.component.scss']
})
export class EditpageComponent implements OnInit {
  statusList:any=[]
  metadataList:any=[]
  selectedStatus:any
  enteredSurgeonName:any
  enteredOtNumber:any
  enteredUHID:any
  updateMsg:boolean=false;

  editdata=new FormGroup({
    uhid: new FormControl({value:'',disabled:true}),
    status: new FormControl(''),
    surgeonName: new FormControl(''),
    otNumber:new FormControl('')
  })
  constructor(private http:HttpClient,private router:ActivatedRoute) {}

  ngOnInit(): void {
    console.log(this.selectedStatus)
    this.getOTMetadata();
    console.log(this.router.snapshot.params['id']);
    this.getOTDataById(this.router.snapshot.params['id']).subscribe(response=>{
      console.log(response)
      this.enteredUHID=response.uhid;
      this.editdata=new FormGroup({
        uhid: new FormControl(response.uhid),
        status: new FormControl(response.status),
        surgeonName: new FormControl(response.surgeonName),
        otNumber:new FormControl(response.otNumber)
      })
    })
    
  }

  getAllStatus(){
    this.http.get<any>('http://localhost:9091/metadata/status').subscribe(response=>{
    console.log(response)  
    this.statusList=response;
    })
  }
  getOTMetadata(){
    this.http.get<any>('http://localhost:9091/metadata').subscribe(response=>{
    console.log(response)  
    this.metadataList=response;
    })
  }
  getOTDataById(id:any){
    return this.http.get<any>(`http://localhost:9091/all-status/${id}`);
  }
  updateOTDataImpl(){
    const body={
        uhid: this.enteredUHID,
        status: this.selectedStatus,
        surgeonName: this.enteredSurgeonName,
        otNumber:this.enteredOtNumber
    }
    this.updateOTData(this.router.snapshot.params['id'],body).subscribe(response=>{
      console.log(response,'Data updated');
      this.updateMsg=true;
    })
    window.setTimeout(function(){location.reload},2000);
  }
  updateOTData(id:any,data:any){
    return this.http.put<any>(`http://localhost:9091/all-status/${id}`,data);
  }
  changeStatus(e:any) {
    this.selectedStatus=e.target.value;
  }
  // updateOTData(){
  //   console.log('update');
  //   console.log(this.selectedStatus)
  //   console.log(this.enteredSurgeonName)
  //  const body={
  //       status: this.selectedStatus,
  //       surgeonName: this.enteredSurgeonName,
  //       otNumber: this.enteredOtNumber,
  //       uhid: this.router.snapshot.params['id']
  //  }
  //  this.http.put<any>('http://localhost:9091/all-status/'+this.router.snapshot.params['id'],body).subscribe(response=>{ 
  //  console.log(response,'updated successfully');
  //  })
  // }
 
  
}

