import { Component, OnInit } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import {EditpageComponent} from '../editpage/editpage.component'
import { MdbModalRef, MdbModalService } from 'mdb-angular-ui-kit/modal';
import { Router } from '@angular/router';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  modalRef: MdbModalRef<EditpageComponent>;
  title = 'ot-status-monitoring-system';
  UHID:any;
  otstatus:any;
  presentMsg:boolean=false;
  errorMsg:boolean=false;
  mservice:MdbModalService;
  constructor(private http:HttpClient) { 
  }
  ngOnInit(): void {
  
  }

 
  // redirect(){
  //   this.router.navigateByUrl('/edit-data');
  // }
  getUHID(){
    return this.http.get<any>('http://localhost:9091/all-status/'+this.UHID);
    
  }
  searchUHID(){
    this.http.get<any>('http://localhost:9091/all-status/'+this.UHID).subscribe(response=>{this.otstatus=response;this.presentMsg=true},error=>{if(error.status==404){this.errorMsg=true}});
  }

  deleteOTData(){
    this.http.delete<any>('http://localhost:9091/all-status/'+this.UHID).subscribe(response=>{
      alert('Data Deleted Successfully');
    })
  }
}
