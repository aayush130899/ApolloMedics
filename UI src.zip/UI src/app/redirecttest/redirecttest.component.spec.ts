import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RedirecttestComponent } from './redirecttest.component';

describe('RedirecttestComponent', () => {
  let component: RedirecttestComponent;
  let fixture: ComponentFixture<RedirecttestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RedirecttestComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RedirecttestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
