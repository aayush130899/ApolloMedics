import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {HomeComponent} from './home/home.component'
import { TestComponent } from './test/test.component';
import { EditpageComponent } from './editpage/editpage.component';
import { RedirecttestComponent } from './redirecttest/redirecttest.component';
import { DeletepageComponent } from './deletepage/deletepage.component';
import { CreatepageComponent } from './createpage/createpage.component';
import { AllStatusesComponent } from './all-statuses/all-statuses.component';
const routes: Routes = [
 { path: '', redirectTo:"Home",pathMatch:"full"},
  {path:'Home',component:HomeComponent},
  {path:'test',component:TestComponent},
  {path:'edit/:id',component:EditpageComponent},
  {path:'ed',component:RedirecttestComponent},
  {path:'delete/:id',component:DeletepageComponent},
  {path:'create',component:CreatepageComponent},
  {path:'all-status',component:AllStatusesComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
